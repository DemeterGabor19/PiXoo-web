<?php

if (!defined('ABSPATH')) {
    exit;
}

define('PIXOO_THEME_VERSION', '0.1.4');

function pixoo_asset($path = '')
{
    return get_template_directory_uri() . '/assets/' . ltrim($path, '/');
}

function pixoo_asset_path($path = '')
{
    return get_template_directory() . '/assets/' . ltrim($path, '/');
}

function pixoo_asset_version($path)
{
    $file_path = pixoo_asset_path($path);

    if (file_exists($file_path)) {
        return (string) filemtime($file_path);
    }

    return PIXOO_THEME_VERSION;
}

function pixoo_find_asset($pattern)
{
    $matches = glob(pixoo_asset_path($pattern));

    if (!$matches) {
        return null;
    }

    usort($matches, static function ($first, $second) {
        return filemtime($second) <=> filemtime($first);
    });

    return str_replace('\\', '/', str_replace(pixoo_asset_path(), '', $matches[0]));
}

function pixoo_theme_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);

    register_nav_menus([
        'primary' => __('Primary navigation', 'pixoo'),
        'footer' => __('Footer navigation', 'pixoo'),
    ]);
}
add_action('after_setup_theme', 'pixoo_theme_setup');

function pixoo_enqueue_assets()
{
    $main_style = pixoo_find_asset('css/main-*.css') ?: 'css/main.css';

    wp_enqueue_style(
        'pixoo-main',
        pixoo_asset($main_style),
        [],
        pixoo_asset_version($main_style)
    );

    if (file_exists(pixoo_asset_path('css/wp-overrides.css'))) {
        wp_enqueue_style(
            'pixoo-wp-overrides',
            pixoo_asset('css/wp-overrides.css'),
            ['pixoo-main'],
            pixoo_asset_version('css/wp-overrides.css')
        );
    }

    $main_script = pixoo_find_asset('js/main-*.js');

    if ($main_script) {
        wp_enqueue_script(
            'pixoo-main',
            pixoo_asset($main_script),
            [],
            pixoo_asset_version($main_script),
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'pixoo_enqueue_assets');

function pixoo_module_script_tag($tag, $handle, $src)
{
    if ($handle !== 'pixoo-main') {
        return $tag;
    }

    return '<script type="module" crossorigin src="' . esc_url($src) . '"></script>';
}
add_filter('script_loader_tag', 'pixoo_module_script_tag', 10, 3);

function pixoo_preload_assets()
{
    echo '<link rel="preload" href="' . esc_url(pixoo_asset('fonts/Pulchella - Personal Used.woff2')) . '" as="font" type="font/woff2" crossorigin>' . "\n";
}
add_action('wp_head', 'pixoo_preload_assets', 1);

function pixoo_url($path = '/')
{
    return home_url($path);
}

function pixoo_static_section($section)
{
    $file = get_template_directory() . '/template-parts/sections/' . $section . '.html';

    if (!file_exists($file)) {
        return;
    }

    $html = file_get_contents($file);

    if ($html === false) {
        return;
    }

    $asset_base = esc_url(get_template_directory_uri() . '/assets/');

    $html = str_replace('"/assets/', '"' . $asset_base, $html);
    $html = str_replace("'/assets/", "'" . $asset_base, $html);

    $links = [
        '/contact.html' => '/kapcsolat/',
        '/references.html' => '/referenciak/',
        '/pricing.html' => '/arak/',
        '/weboldal-allapotfelmeres.html' => '/allapotfemeres/',
        '/blog.html' => '/blog/',
        '/privacy-policy.html' => 'https://staging.pixoo.hu/adatkezelesi-tajekoztato/',
        '/terms.html' => 'https://staging.pixoo.hu/feltetelek/',
        '/' => '/',
    ];

    foreach ($links as $static_url => $wp_url) {
        $target_url = preg_match('#^https?://#', $wp_url) ? $wp_url : home_url($wp_url);
        $html = str_replace('href="' . $static_url . '"', 'href="' . esc_url($target_url) . '"', $html);
    }

    if (function_exists('pixoo_home_filter_section_html')) {
        $html = pixoo_home_filter_section_html($section, $html);
    }

    if (function_exists('pixoo_references_filter_section_html')) {
        $html = pixoo_references_filter_section_html($section, $html);
    }

    if (function_exists('pixoo_contact_filter_section_html')) {
        $html = pixoo_contact_filter_section_html($section, $html);
    }

    if (function_exists('pixoo_pricing_filter_section_html')) {
        $html = pixoo_pricing_filter_section_html($section, $html);
    }

    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function pixoo_has_acf()
{
    return function_exists('get_field');
}

function pixoo_website_audit_short_url()
{
    $path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');

    if (!in_array($path, array('allapotfemeres', 'allapotfelmeres'), true)) {
        return;
    }

    status_header(200);
    require get_template_directory() . '/template-website-audit.php';
    exit;
}
add_action('template_redirect', 'pixoo_website_audit_short_url');

require_once get_template_directory() . '/inc/home-acf.php';
require_once get_template_directory() . '/inc/references-acf.php';
require_once get_template_directory() . '/inc/contact-form.php';
require_once get_template_directory() . '/inc/blog.php';
