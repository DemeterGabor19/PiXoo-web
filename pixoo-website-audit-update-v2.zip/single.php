<?php

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main>
  <?php while (have_posts()) : the_post(); ?>
    <article class="blog-post" aria-labelledby="blog-post-title">
      <div class="blog-post__container">
        <a class="blog-post__back" href="<?php echo esc_url(pixoo_blog_index_url()); ?>"><?php esc_html_e('Vissza a bloghoz', 'pixoo'); ?></a>

        <header class="blog-post__hero">
          <div class="blog-post__intro">
            <p class="blog-post__eyebrow"><?php echo esc_html(pixoo_blog_category_label(get_the_ID())); ?></p>
            <h1 id="blog-post-title"><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?>
              <p class="blog-post__lead"><?php echo esc_html(get_the_excerpt()); ?></p>
            <?php endif; ?>
            <div class="blog-post__meta" aria-label="<?php echo esc_attr__('Cikk információk', 'pixoo'); ?>">
              <time datetime="<?php echo esc_attr(get_the_date('Y-m-d')); ?>"><?php echo esc_html(get_the_date('Y. F j.')); ?></time>
              <span><?php echo esc_html(pixoo_blog_reading_time(get_the_ID())); ?></span>
              <span><?php echo esc_html(get_the_author()); ?></span>
            </div>
          </div>

          <figure class="blog-post__cover">
            <img
              src="<?php echo esc_url(pixoo_blog_image_url(get_the_ID())); ?>"
              alt="<?php echo esc_attr(get_the_title()); ?>"
            >
          </figure>
        </header>

        <div class="blog-post__layout">
          <div class="blog-post__content">
            <?php the_content(); ?>
          </div>

          <aside class="blog-post__aside" aria-label="<?php echo esc_attr__('Cikk oldalsáv', 'pixoo'); ?>">
            <div class="blog-post__toc">
              <p><?php esc_html_e('Tartalom', 'pixoo'); ?></p>
              <a href="#blog-post-title"><?php esc_html_e('Áttekintés', 'pixoo'); ?></a>
              <a href="<?php echo esc_url(home_url('/arak/')); ?>"><?php esc_html_e('Árak és kalkulátor', 'pixoo'); ?></a>
              <a href="<?php echo esc_url(home_url('/referenciak/')); ?>"><?php esc_html_e('Referenciák', 'pixoo'); ?></a>
            </div>

            <div class="blog-post__cta">
              <p class="blog-post__eyebrow"><?php esc_html_e('Projekted van?', 'pixoo'); ?></p>
              <h2><?php esc_html_e('Nézzük meg, milyen oldalra van szükséged', 'pixoo'); ?></h2>
              <p>
                <?php esc_html_e('A kalkulátor jó indulás, de egy rövid egyeztetés sokszor gyorsabban tisztázza, mi kell valóban.', 'pixoo'); ?>
              </p>
              <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>"><?php esc_html_e('Kapcsolatfelvétel', 'pixoo'); ?></a>
            </div>
          </aside>
        </div>

        <?php
        $related = new WP_Query([
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => 2,
            'post__not_in' => [get_the_ID()],
            'ignore_sticky_posts' => true,
        ]);
        ?>
        <?php if ($related->have_posts()) : ?>
          <section class="blog-post__related" aria-labelledby="related-title">
            <div class="blog-post__related-head">
              <p class="blog-post__eyebrow"><?php esc_html_e('Kapcsolódó cikkek', 'pixoo'); ?></p>
              <h2 id="related-title"><?php esc_html_e('Olvass tovább', 'pixoo'); ?></h2>
            </div>

            <div class="blog-post__related-grid">
              <?php while ($related->have_posts()) : ?>
                <?php $related->the_post(); ?>
                <?php pixoo_blog_card(get_post()); ?>
              <?php endwhile; ?>
            </div>
          </section>
        <?php endif; ?>
        <?php wp_reset_postdata(); ?>
      </div>
    </article>
  <?php endwhile; ?>
</main>

<?php
get_footer();
