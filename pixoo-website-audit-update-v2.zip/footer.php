<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
    <footer class="site-footer">
      <div class="site-footer__container">
        <div class="site-footer__main">
          <div class="site-footer__brand">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="site-footer__logo" aria-label="PiXoo kezdőlap">
              <img src="<?php echo esc_url(pixoo_asset('images/common/logo-mark.png')); ?>" alt="PiXoo logó" width="512" height="512" loading="lazy">
            </a>
            <p>
              Modern, gyors és átgondolt online felületek vállalkozásoknak. Design,
              technikai stabilitás és szerkeszthető WordPress alapok egy rendszerben.
            </p>

            <div class="site-footer__socials" aria-label="Social elérhetőségek">
              <a class="site-footer__social-link" href="https://www.linkedin.com/in/g%C3%A1bor-demeter-41a0bba7/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <img src="<?php echo esc_url(pixoo_asset('icons/linkedin-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
              <a class="site-footer__social-link" href="https://github.com/DemeterGabor19" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                <img src="<?php echo esc_url(pixoo_asset('icons/github-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
              <a class="site-footer__social-link" href="https://www.facebook.com/PiXoo.web" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <img src="<?php echo esc_url(pixoo_asset('icons/facebook-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
            </div>
          </div>

          <nav class="site-footer__nav" aria-label="Footer navigáció">
            <div>
              <h2>Oldalak</h2>
              <a href="<?php echo esc_url(home_url('/')); ?>">Kezdőlap</a>
              <a href="<?php echo esc_url(home_url('/referenciak/')); ?>">Referenciák</a>
              <a href="<?php echo esc_url(home_url('/arak/')); ?>">Árak</a>
              <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>
            </div>

            <div>
              <h2>Kapcsolat</h2>
              <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>">Ajánlatkérés</a>
              <a href="mailto:hello@pixoo.hu">hello@pixoo.hu</a>
              <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>">Konzultáció</a>
            </div>
          </nav>

          <div class="site-footer__cta">
            <p class="site-footer__eyebrow">Következő lépés</p>
            <h2>Indulhat a projekted?</h2>
            <p>
              Írd le röviden, mire lenne szükséged, és összerakjuk a következő
              lépéseket.
            </p>
            <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>">Beszéljünk róla</a>
          </div>
        </div>

        <div class="site-footer__bottom">
          <p>&copy; <?php echo esc_html(date('Y')); ?> PiXoo. Minden jog fenntartva.</p>
          <div>
            <a href="https://staging.pixoo.hu/adatkezelesi-tajekoztato/">Adatkezelési tájékoztató</a>
            <a href="https://staging.pixoo.hu/feltetelek/">Feltételek</a>
          </div>
        </div>
      </div>
    </footer>

    <?php wp_footer(); ?>
  </body>
</html>
