<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <header class="site-header">
      <div class="container">
        <div class="site-header__content">
          <div class="site-header__inner">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="site-header__brand" aria-label="PiXoo kezdőlap">
              <img
                src="<?php echo esc_url(pixoo_asset('images/common/logo-mark.png')); ?>"
                alt="PiXoo logó"
                width="512"
                height="512"
                fetchpriority="high"
              >
            </a>

            <nav class="site-header__nav" aria-label="Fő navigáció">
              <ul class="site-header__menu">
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/')); ?>">Kezdőlap</a></li>
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/referenciak/')); ?>">Referenciák</a></li>
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/pricing/')); ?>">Árak</a></li>
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/weboldal-allapotfelmeres/')); ?>">Állapotfelmérés</a></li>
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a></li>
                <li class="site-header__menu-item"><a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>">Kapcsolat</a></li>
              </ul>

              <div class="site-header__socials site-header__socials--mobile">
                <a class="site-header__social-link" href="https://www.linkedin.com/in/g%C3%A1bor-demeter-41a0bba7/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                  <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/linkedin-icon.svg')); ?>" alt="" width="18" height="18">
                </a>
                <a class="site-header__social-link" href="https://github.com/DemeterGabor19" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                  <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/github-icon.svg')); ?>" alt="" width="18" height="18">
                </a>
                <a class="site-header__social-link" href="https://www.facebook.com/PiXoo.web" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                  <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/facebook-icon.svg')); ?>" alt="" width="18" height="18">
                </a>
              </div>
            </nav>

            <div class="site-header__socials site-header__socials--desktop">
              <a class="site-header__social-link" href="https://www.linkedin.com/in/g%C3%A1bor-demeter-41a0bba7/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/linkedin-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
              <a class="site-header__social-link" href="https://github.com/DemeterGabor19" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/github-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
              <a class="site-header__social-link" href="https://www.facebook.com/PiXoo.web" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <img class="site-header__social-icon" src="<?php echo esc_url(pixoo_asset('icons/facebook-icon.svg')); ?>" alt="" width="18" height="18">
              </a>
            </div>

            <button class="site-header__toggle" type="button" aria-label="Menü megnyitása" aria-expanded="false">
              <span></span>
              <span></span>
            </button>
          </div>
        </div>
      </div>
    </header>
