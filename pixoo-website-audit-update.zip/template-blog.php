<?php
/**
 * Template Name: Blog
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$paged = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
$blog_query = new WP_Query([
    'post_type' => 'post',
    'post_status' => 'publish',
    'paged' => $paged,
    'posts_per_page' => 7,
]);
$posts = $blog_query->posts;
$featured = $posts[0] ?? null;
$cards = array_slice($posts, 1);
$categories = get_categories([
    'hide_empty' => true,
]);
?>

<main>
  <section class="blog-index" aria-labelledby="blog-title">
    <div class="blog-index__container">
      <header class="blog-index__header">
        <p class="blog-index__eyebrow"><?php esc_html_e('Blog', 'pixoo'); ?></p>
        <h1 id="blog-title" class="blog-index__title">
          <?php esc_html_e('Weboldalkészítés, WordPress és digitális jelenlét érthetően', 'pixoo'); ?>
        </h1>
        <p class="blog-index__lead">
          <?php esc_html_e('Gyakorlati cikkek vállalkozóknak: mikor milyen online megoldásra van szükség, hogyan érdemes gondolkodni SEO-ról, WordPressről, designról és online ajánlatkérésről.', 'pixoo'); ?>
        </p>
      </header>

      <div class="blog-tools" aria-label="<?php echo esc_attr__('Blog szűrők', 'pixoo'); ?>">
        <div class="blog-tools__filters" data-blog-filters>
          <button class="is-active" type="button" data-blog-filter="all">
            <?php esc_html_e('Összes', 'pixoo'); ?>
          </button>
          <?php foreach ($categories as $category) : ?>
            <button type="button" data-blog-filter="<?php echo esc_attr($category->slug); ?>">
              <?php echo esc_html($category->name); ?>
            </button>
          <?php endforeach; ?>
        </div>

        <label class="blog-tools__search">
          <span><?php esc_html_e('Keresés', 'pixoo'); ?></span>
          <input
            type="search"
            placeholder="<?php echo esc_attr__('Keresés a cikkek között', 'pixoo'); ?>"
            data-blog-search
          >
        </label>
      </div>

      <?php if ($featured) : ?>
        <article class="blog-featured" data-blog-card data-blog-category="<?php echo esc_attr(pixoo_blog_category_slugs($featured->ID)); ?>">
          <a class="blog-featured__media" href="<?php echo esc_url(get_permalink($featured->ID)); ?>">
            <img
              src="<?php echo esc_url(pixoo_blog_image_url($featured->ID)); ?>"
              alt="<?php echo esc_attr(get_the_title($featured->ID)); ?>"
              width="942"
              height="529"
            >
            <span><?php esc_html_e('Kiemelt cikk', 'pixoo'); ?></span>
          </a>
          <div class="blog-featured__content">
            <div class="blog-featured__meta">
              <span class="blog-featured__topic"><?php echo esc_html(pixoo_blog_category_label($featured->ID)); ?></span>
              <time datetime="<?php echo esc_attr(get_the_date('Y-m-d', $featured->ID)); ?>"><?php echo esc_html(get_the_date('Y. F j.', $featured->ID)); ?></time>
              <span class="blog-featured__readtime"><?php echo esc_html(pixoo_blog_reading_time($featured->ID)); ?></span>
            </div>
            <h2>
              <a href="<?php echo esc_url(get_permalink($featured->ID)); ?>"><?php echo esc_html(get_the_title($featured->ID)); ?></a>
            </h2>
            <p><?php echo esc_html(pixoo_blog_excerpt($featured->ID)); ?></p>
            <a class="blog-featured__link" href="<?php echo esc_url(get_permalink($featured->ID)); ?>"><?php esc_html_e('Elolvasom', 'pixoo'); ?></a>
          </div>
        </article>
      <?php endif; ?>

      <?php if ($cards) : ?>
        <div class="blog-grid" data-blog-grid>
          <?php foreach ($cards as $card_post) : ?>
            <?php pixoo_blog_card($card_post); ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if (!$posts) : ?>
        <p class="blog-index__empty">
          <?php esc_html_e('Még nincs publikált blogcikk. Amint kikerül az első bejegyzés, itt fog megjelenni.', 'pixoo'); ?>
        </p>
      <?php endif; ?>

      <p class="blog-index__empty" hidden data-blog-empty>
        <?php esc_html_e('Nincs találat erre a szűrésre.', 'pixoo'); ?>
      </p>

      <?php
      $pagination = paginate_links([
          'total' => $blog_query->max_num_pages,
          'current' => $paged,
          'prev_text' => __('Előző', 'pixoo'),
          'next_text' => __('Következő', 'pixoo'),
      ]);
      ?>
      <?php if ($pagination) : ?>
        <nav class="blog-pagination" aria-label="<?php echo esc_attr__('Blog lapozás', 'pixoo'); ?>" data-blog-pagination>
          <?php echo wp_kses_post($pagination); ?>
        </nav>
      <?php endif; ?>

      <section class="blog-cta" aria-labelledby="blog-cta-title">
        <div>
          <p class="blog-index__eyebrow"><?php esc_html_e('Következő lépés', 'pixoo'); ?></p>
          <h2 id="blog-cta-title"><?php esc_html_e('Nemcsak olvasnál róla?', 'pixoo'); ?></h2>
          <p>
            <?php esc_html_e('Ha már körvonalazódik, milyen online felületre lenne szükséged, nézzük meg együtt a lehetőségeket és a következő lépéseket.', 'pixoo'); ?>
          </p>
        </div>
        <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>"><?php esc_html_e('Beszéljünk a projektedről', 'pixoo'); ?></a>
      </section>
    </div>
  </section>
</main>

<?php
wp_reset_postdata();
get_footer();
