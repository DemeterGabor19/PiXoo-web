<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="not-found">
  <div class="not-found__container">
    <p class="not-found__eyebrow">404</p>
    <h1>Az oldal nem található</h1>
    <p>Lehet, hogy az oldal elköltözött, vagy már nem érhető el ezen az URL-en.</p>
    <div class="not-found__actions">
      <a href="<?php echo esc_url(home_url('/')); ?>">Vissza a kezdőlapra</a>
      <a href="<?php echo esc_url(home_url('/kapcsolat/')); ?>">Kapcsolat</a>
    </div>
  </div>
</main>

<?php
get_footer();
