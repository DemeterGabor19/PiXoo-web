<?php
/**
 * Template Name: Referenciak
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main>
  <?php pixoo_static_section('references-showcase'); ?>
</main>

<?php wp_footer(); ?>
  </body>
</html>
