<?php
if (!defined('ABSPATH')) {
    exit;
}

$pixoo_page_id = get_queried_object_id();
$pixoo_page_slug = (string) get_post_field('post_name', $pixoo_page_id);
$pixoo_page_title_slug = sanitize_title((string) get_the_title($pixoo_page_id));
$pixoo_request_path = isset($_SERVER['REQUEST_URI']) ? trim((string) wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH), '/') : '';

if (
    in_array($pixoo_page_slug, ['feltetelek', 'terms'], true)
    || in_array($pixoo_page_title_slug, ['feltetelek', 'hasznalati-es-szolgaltatasi-feltetelek'], true)
    || strpos($pixoo_request_path, 'feltetelek') !== false
    || strpos($pixoo_request_path, 'terms') !== false
) {
    require get_template_directory() . '/page-feltetelek.php';
    return;
}

if (
    in_array($pixoo_page_slug, ['adatkezelesi-tajekoztato', 'privacy-policy'], true)
    || in_array($pixoo_page_title_slug, ['adatkezelesi-tajekoztato', 'adatvedelem'], true)
    || strpos($pixoo_request_path, 'adatkezeles') !== false
    || strpos($pixoo_request_path, 'privacy-policy') !== false
) {
    require get_template_directory() . '/page-adatkezelesi-tajekoztato.php';
    return;
}

get_header();
?>

<main class="legal-page">
  <section class="legal-hero">
    <div class="legal-hero__container">
      <?php while (have_posts()) : the_post(); ?>
        <p class="legal-hero__eyebrow"><?php esc_html_e('PiXoo', 'pixoo'); ?></p>
        <h1><?php the_title(); ?></h1>
        <?php if (has_excerpt()) : ?>
          <p><?php echo esc_html(get_the_excerpt()); ?></p>
        <?php endif; ?>
      <?php endwhile; ?>
      <?php rewind_posts(); ?>
    </div>
  </section>

  <section class="legal-content">
    <div class="legal-content__container">
      <article class="legal-card">
        <?php
        while (have_posts()) :
            the_post();
            the_content();
        endwhile;
        ?>
      </article>
    </div>
  </section>
</main>

<?php
get_footer();
