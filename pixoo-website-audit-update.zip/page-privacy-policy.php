<?php
require get_template_directory() . '/page-adatkezelesi-tajekoztato.php';
