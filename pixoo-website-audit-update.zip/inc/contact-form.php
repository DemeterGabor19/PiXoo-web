<?php

if (!defined('ABSPATH')) {
    exit;
}

function pixoo_contact_turnstile_site_key()
{
    if (defined('PIXOO_TURNSTILE_SITE_KEY')) {
        return (string) PIXOO_TURNSTILE_SITE_KEY;
    }

    $site_key = getenv('PIXOO_TURNSTILE_SITE_KEY');

    return $site_key ? (string) $site_key : '1x00000000000000000000AA';
}

function pixoo_contact_turnstile_secret_key()
{
    if (defined('PIXOO_TURNSTILE_SECRET_KEY')) {
        return (string) PIXOO_TURNSTILE_SECRET_KEY;
    }

    $secret_key = getenv('PIXOO_TURNSTILE_SECRET_KEY');

    if ($secret_key) {
        return (string) $secret_key;
    }

    if (pixoo_contact_turnstile_site_key() === '1x00000000000000000000AA') {
        return '1x0000000000000000000000000000000AA';
    }

    return '';
}

function pixoo_contact_filter_section_html($section, $html)
{
    if (!in_array($section, ['contact-start', 'website-audit'], true)) {
        return $html;
    }

    $form_open = $section === 'website-audit'
        ? '<form class="contact-form website-audit-form" data-contact-form>'
        : '<form class="contact-form" data-contact-form>';
    $form_class = $section === 'website-audit'
        ? 'contact-form website-audit-form'
        : 'contact-form';
    $form_replacement = sprintf(
        '<form class="%s" data-contact-form data-wp-submit method="post" action="%s">',
        esc_attr($form_class),
        esc_url(rest_url('pixoo/v1/contact'))
    );

    $html = str_replace($form_open, $form_replacement, $html);
    $html = preg_replace(
        '/data-sitekey="[^"]*"/',
        'data-sitekey="' . esc_attr(pixoo_contact_turnstile_site_key()) . '"',
        $html,
        1
    ) ?: $html;

    return $html;
}

function pixoo_pricing_filter_section_html($section, $html)
{
    if ($section !== 'pricing-configurator') {
        return $html;
    }

    $form_open = '<form class="pricing-request-form" data-pricing-request-form>';
    $form_replacement = sprintf(
        '<form class="pricing-request-form" data-pricing-request-form data-wp-submit method="post" action="%s">',
        esc_url(rest_url('pixoo/v1/contact'))
    );

    $html = str_replace($form_open, $form_replacement, $html);
    $html = preg_replace(
        '/data-sitekey="[^"]*"/',
        'data-sitekey="' . esc_attr(pixoo_contact_turnstile_site_key()) . '"',
        $html,
        1
    ) ?: $html;
    return $html;
}

function pixoo_contact_clean_text_from_array($data, $key, $max_length = 300)
{
    $value = isset($data[$key]) ? $data[$key] : '';
    $value = is_string($value) ? sanitize_text_field(wp_unslash($value)) : '';

    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $max_length);
    }

    return substr($value, 0, $max_length);
}

function pixoo_contact_clean_message_from_array($data, $key, $max_length = 3000)
{
    $value = isset($data[$key]) ? $data[$key] : '';
    $value = is_string($value) ? sanitize_textarea_field(wp_unslash($value)) : '';

    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $max_length);
    }

    return substr($value, 0, $max_length);
}

function pixoo_contact_verify_turnstile($token)
{
    $secret_key = pixoo_contact_turnstile_secret_key();

    if ($secret_key === '') {
        return new WP_Error(
            'pixoo_turnstile_missing_secret',
            'A Turnstile titkos kulcs nincs beállítva. Add meg a PIXOO_TURNSTILE_SECRET_KEY konstansban vagy környezeti változóban.'
        );
    }

    $response = wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
        'timeout' => 10,
        'body' => [
            'secret' => $secret_key,
            'response' => $token,
            'remoteip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
        ],
    ]);

    if (is_wp_error($response)) {
        return $response;
    }

    $body = json_decode((string) wp_remote_retrieve_body($response), true);

    return is_array($body) && !empty($body['success']);
}

function pixoo_contact_error($message, $status = 400)
{
    return new WP_Error('pixoo_contact_error', $message, ['status' => $status]);
}

function pixoo_contact_success_message()
{
    return 'Köszönöm, megkaptam az üzeneted. Átnézem a részleteket, és jellemzően 1 munkanapon belül válaszolok.';
}

function pixoo_contact_fallback_error_message()
{
    return 'Most nem sikerült elküldeni az üzenetet. Kérlek, próbáld újra pár perc múlva, vagy írj közvetlenül a hello@pixoo.hu címre.';
}

function pixoo_contact_mailbox()
{
    if (defined('PIXOO_CONTACT_EMAIL')) {
        return sanitize_email((string) PIXOO_CONTACT_EMAIL);
    }

    return 'hello@pixoo.hu';
}

function pixoo_contact_submission_key($parts)
{
    $payload = wp_json_encode($parts);

    if (!is_string($payload)) {
        $payload = implode('|', array_map('strval', $parts));
    }

    return 'pixoo_contact_' . hash('sha256', $payload);
}

function pixoo_contact_process($data)
{
    $selected_services = pixoo_contact_clean_message_from_array($data, 'selected_services', 5000);
    $is_pricing_request = $selected_services !== '';

    if (!empty($data['website'])) {
        return ['message' => pixoo_contact_success_message()];
    }

    $name = pixoo_contact_clean_text_from_array($data, 'name');
    $email = isset($data['email']) ? sanitize_email(wp_unslash($data['email'])) : '';
    $phone = pixoo_contact_clean_text_from_array($data, 'phone');
    $project = pixoo_contact_clean_text_from_array($data, 'project');
    $project_type = pixoo_contact_clean_text_from_array($data, 'project_type');
    $timeline = pixoo_contact_clean_text_from_array($data, 'timeline');
    $budget = pixoo_contact_clean_text_from_array($data, 'budget');
    $content_status = pixoo_contact_clean_text_from_array($data, 'content_status');
    $website_url = isset($data['website_url']) ? esc_url_raw(wp_unslash($data['website_url'])) : '';
    $delivery_preference = pixoo_contact_clean_text_from_array($data, 'delivery_preference');
    $message = pixoo_contact_clean_message_from_array($data, 'message');
    $turnstile_token = pixoo_contact_clean_text_from_array($data, 'cf-turnstile-response', 1000);
    $is_audit_request = $project_type === 'Weboldal Állapotfelmérés';

    if ($name === '' || $email === '' || (!$is_pricing_request && !$is_audit_request && ($project_type === '' || $timeline === '' || $message === ''))) {
        return pixoo_contact_error('Kérlek, töltsd ki a kötelező mezőket.');
    }

    if ($is_audit_request && ($project === '' || $website_url === '' || $delivery_preference === '')) {
        return pixoo_contact_error('Kérlek, töltsd ki a kötelező mezőket.');
    }

    if (!is_email($email)) {
        return pixoo_contact_error('Kérlek, érvényes e-mail címet adj meg.');
    }

    if (empty($data['privacy_consent'])) {
        return pixoo_contact_error('Az adatkezelési hozzájárulás szükséges az elküldéshez.');
    }

    if ($turnstile_token === '') {
        return pixoo_contact_error('Kérlek, erősítsd meg a biztonsági ellenőrzést.');
    }

    $turnstile_result = pixoo_contact_verify_turnstile($turnstile_token);

    if (is_wp_error($turnstile_result)) {
        return pixoo_contact_error(pixoo_contact_fallback_error_message(), 500);
    }

    if (!$turnstile_result) {
        return pixoo_contact_error('Nem sikerült befejezni a biztonsági ellenőrzést. Kérlek, próbáld újra.', 403);
    }

    $mailbox = pixoo_contact_mailbox();
    $to = apply_filters('pixoo_contact_recipient', $mailbox);
    $subject = sprintf($is_pricing_request ? 'Új árkalkulátor ajánlatkérés: %s' : ($is_audit_request ? 'Új Weboldal Állapotfelmérés kérés: %s' : 'Új projektigény: %s'), $name);
    $body_lines = [
        $is_pricing_request
            ? 'Új árkalkulátor ajánlatkérés érkezett a PiXoo weboldalról.'
            : ($is_audit_request ? 'Új Weboldal Állapotfelmérés kérés érkezett a PiXoo weboldalról.' : 'Új kapcsolatfelvétel érkezett a PiXoo weboldalról.'),
        '',
        'Név: ' . $name,
        'E-mail: ' . $email,
        'Telefonszám: ' . ($phone ?: '-'),
        'Cég / projekt: ' . ($project ?: '-'),
    ];

    if ($is_pricing_request) {
        $body_lines = array_merge($body_lines, [
            '',
            'Kiválasztott szolgáltatások:',
            $selected_services,
            '',
            'Üzenet:',
            $message ?: '-',
        ]);
    } elseif ($is_audit_request) {
        $body_lines = array_merge($body_lines, [
            'Weboldal címe: ' . $website_url,
            'Kért forma: ' . $delivery_preference,
            '',
            'Kiemelt figyelmet kér erre:',
            $message ?: '-',
        ]);
    } else {
        $body_lines = array_merge($body_lines, [
            'Projekt típusa: ' . $project_type,
            'Tervezett indulás: ' . $timeline,
            'Hozzávetőleges keret: ' . ($budget ?: '-'),
            'Tartalom állapota: ' . ($content_status ?: '-'),
            '',
            'Projektleírás:',
            $message,
        ]);
    }

    $body = implode("\n", $body_lines);
    $headers = [
        'Content-Type: text/plain; charset=UTF-8',
        'From: PiXoo <' . $mailbox . '>',
        'Reply-To: ' . $name . ' <' . $email . '>',
    ];

    $submission_key = pixoo_contact_submission_key([
        'type' => $is_pricing_request ? 'pricing' : 'contact',
        'name' => $name,
        'email' => strtolower($email),
        'phone' => $phone,
        'project' => $project,
        'website_url' => $website_url,
        'delivery_preference' => $delivery_preference,
        'selected_services' => $selected_services,
        'message' => $message,
    ]);

    if (get_transient($submission_key)) {
        return ['message' => pixoo_contact_success_message()];
    }

    set_transient($submission_key, '1', 10 * MINUTE_IN_SECONDS);

    if (!wp_mail($to, $subject, $body, $headers)) {
        delete_transient($submission_key);
        return pixoo_contact_error('Az üzenetet most nem sikerült továbbítani. Kérlek, próbáld újra pár perc múlva, vagy írj közvetlenül a hello@pixoo.hu címre.', 500);
    }

    return ['message' => pixoo_contact_success_message()];
}

function pixoo_contact_rest_response($request)
{
    $result = pixoo_contact_process($request->get_params());

    if (is_wp_error($result)) {
        return $result;
    }

    return rest_ensure_response([
        'success' => true,
        'data' => $result,
    ]);
}

function pixoo_register_contact_rest_route()
{
    register_rest_route('pixoo/v1', '/contact', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'pixoo_contact_rest_response',
        'permission_callback' => '__return_true',
    ]);
}
add_action('rest_api_init', 'pixoo_register_contact_rest_route');

function pixoo_handle_contact_form()
{
    $result = pixoo_contact_process($_POST);

    if (is_wp_error($result)) {
        $error_data = $result->get_error_data('pixoo_contact_error');
        $status = is_array($error_data) && isset($error_data['status']) ? (int) $error_data['status'] : 400;
        wp_send_json_error(['message' => $result->get_error_message()], $status ?: 400);
    }

    wp_send_json_success($result);
}
add_action('admin_post_nopriv_pixoo_contact_form', 'pixoo_handle_contact_form');
add_action('admin_post_pixoo_contact_form', 'pixoo_handle_contact_form');
