<?php

if (!defined('ABSPATH')) {
    exit;
}

function pixoo_references_acf_register_fields()
{
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    $fields = [
        [
            'key' => 'field_pixoo_references_images_tab',
            'label' => 'Referencia oldal kepek',
            'name' => '',
            'type' => 'tab',
        ],
    ];

    $labels = [
        'Janko Szörp screenshot',
        'Dabis Meheszet screenshot',
        'Energiatarolo screenshot',
        'Smart Energy Solutions screenshot',
        '4D Manufaktura screenshot',
        'Harmonia Ablak screenshot',
    ];

    foreach ($labels as $index => $label) {
        $number = $index + 1;

        $fields[] = [
            'key' => 'field_pixoo_references_image_' . $number,
            'label' => $label,
            'name' => 'references_showcase_image_' . $number,
            'type' => 'image',
            'return_format' => 'array',
            'preview_size' => 'medium',
        ];
    }

    acf_add_local_field_group([
        'key' => 'group_pixoo_references_images',
        'title' => 'PiXoo referencia oldal kepek',
        'fields' => $fields,
        'location' => [
            [
                [
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'page',
                ],
            ],
        ],
        'position' => 'normal',
        'style' => 'default',
    ]);
}
add_action('acf/init', 'pixoo_references_acf_register_fields');

function pixoo_references_page_id()
{
    $queried_id = get_queried_object_id();

    return $queried_id ? (int) $queried_id : 0;
}

function pixoo_references_acf_image_url($field_name)
{
    if (!function_exists('get_field')) {
        return '';
    }

    $value = get_field($field_name, pixoo_references_page_id());

    if (is_array($value) && !empty($value['url'])) {
        return (string) $value['url'];
    }

    if (is_numeric($value)) {
        $url = wp_get_attachment_image_url((int) $value, 'full');
        return $url ? $url : '';
    }

    if (is_string($value) && $value !== '') {
        return $value;
    }

    return '';
}

function pixoo_references_acf_image($field_name, $loading = 'lazy')
{
    $url = pixoo_references_acf_image_url($field_name);

    if ($url === '') {
        return '';
    }

    return '<img class="reference-browser__image pixoo-acf-image pixoo-acf-image--reference-showcase" src="' . esc_url($url) . '" alt="" loading="' . esc_attr($loading) . '">';
}

function pixoo_references_filter_section_html($section, $html)
{
    if ($section !== 'references-showcase') {
        return $html;
    }

    $first_image = pixoo_references_acf_image('references_showcase_image_1', 'eager');

    if ($first_image !== '') {
        $html = preg_replace(
            '/<img\s+class="reference-browser__image"[^>]*>/',
            $first_image,
            $html,
            1
        ) ?? $html;
    }

    for ($index = 2; $index <= 6; $index++) {
        $image = pixoo_references_acf_image('references_showcase_image_' . $index);

        if ($image === '') {
            continue;
        }

        $html = preg_replace(
            '/<div class="reference-browser__placeholder">Screenshot helye<\/div>/',
            $image,
            $html,
            1
        ) ?? $html;
    }

    return $html;
}
