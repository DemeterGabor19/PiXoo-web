<?php

if (!defined('ABSPATH')) {
    exit;
}

function pixoo_home_acf_register_fields()
{
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    acf_add_local_field_group([
        'key' => 'group_pixoo_home_images',
        'title' => 'PiXoo főoldal képek',
        'fields' => [
            [
                'key' => 'field_pixoo_home_process_tab',
                'label' => 'Így készül el az oldalad',
                'name' => '',
                'type' => 'tab',
            ],
            [
                'key' => 'field_pixoo_home_process_image_1',
                'label' => '1. lépés képe',
                'name' => 'process_image_1',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_process_image_2',
                'label' => '2. lépés képe',
                'name' => 'process_image_2',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_process_image_3',
                'label' => '3. lépés képe',
                'name' => 'process_image_3',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_process_image_4',
                'label' => '4. lépés képe',
                'name' => 'process_image_4',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_benefits_tab',
                'label' => 'Miért válaszd a PiXoo-t?',
                'name' => '',
                'type' => 'tab',
            ],
            [
                'key' => 'field_pixoo_home_benefit_image_1',
                'label' => '1. előny kártya képe',
                'name' => 'benefit_image_1',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_benefit_image_2',
                'label' => '2. előny kártya képe',
                'name' => 'benefit_image_2',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_benefit_image_3',
                'label' => '3. előny kártya képe',
                'name' => 'benefit_image_3',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_benefit_image_4',
                'label' => '4. előny kártya képe',
                'name' => 'benefit_image_4',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_services_tab',
                'label' => 'Több mint weboldal',
                'name' => '',
                'type' => 'tab',
            ],
            [
                'key' => 'field_pixoo_home_service_image_1',
                'label' => 'Fotózás kártya képe',
                'name' => 'service_image_1',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_service_image_2',
                'label' => 'Grafikai megjelenés kártya képe',
                'name' => 'service_image_2',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_service_image_3',
                'label' => 'Online megjelenés kártya képe',
                'name' => 'service_image_3',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_refs_tab',
                'label' => 'Referenciák',
                'name' => '',
                'type' => 'tab',
            ],
            [
                'key' => 'field_pixoo_home_reference_image_1',
                'label' => '1. referencia képe',
                'name' => 'reference_image_1',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_reference_image_2',
                'label' => '2. referencia képe',
                'name' => 'reference_image_2',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_reference_image_3',
                'label' => '3. referencia képe',
                'name' => 'reference_image_3',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_reference_image_4',
                'label' => '4. referencia képe',
                'name' => 'reference_image_4',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
            [
                'key' => 'field_pixoo_home_about_tab',
                'label' => 'Ki áll a PiXoo mögött',
                'name' => '',
                'type' => 'tab',
            ],
            [
                'key' => 'field_pixoo_home_about_image',
                'label' => 'Bemutatkozás képe',
                'name' => 'about_image',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ],
        ],
        'location' => [
            [
                [
                    'param' => 'page_type',
                    'operator' => '==',
                    'value' => 'front_page',
                ],
            ],
        ],
        'position' => 'normal',
        'style' => 'default',
    ]);
}
add_action('acf/init', 'pixoo_home_acf_register_fields');

function pixoo_home_acf_page_id()
{
    $front_page_id = (int) get_option('page_on_front');

    if ($front_page_id > 0) {
        return $front_page_id;
    }

    $queried_id = (int) get_queried_object_id();

    return $queried_id > 0 ? $queried_id : 0;
}

function pixoo_home_acf_image_url($field_name)
{
    $image = pixoo_home_acf_image_data($field_name);

    return $image['url'];
}

function pixoo_home_acf_image_data($field_name)
{
    $empty = [
        'url' => '',
        'title' => '',
        'alt' => '',
    ];

    if (!function_exists('get_field')) {
        return $empty;
    }

    $value = get_field($field_name, pixoo_home_acf_page_id());

    if (is_array($value) && !empty($value['url'])) {
        return [
            'url' => (string) $value['url'],
            'title' => isset($value['title']) ? sanitize_text_field((string) $value['title']) : '',
            'alt' => isset($value['alt']) ? sanitize_text_field((string) $value['alt']) : '',
        ];
    }

    if (is_numeric($value)) {
        $attachment_id = (int) $value;
        $url = wp_get_attachment_image_url($attachment_id, 'full');

        return [
            'url' => $url ? $url : '',
            'title' => sanitize_text_field((string) get_the_title($attachment_id)),
            'alt' => sanitize_text_field((string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true)),
        ];
    }

    if (is_string($value) && $value !== '') {
        return [
            'url' => $value,
            'title' => '',
            'alt' => '',
        ];
    }

    return $empty;
}

function pixoo_home_acf_image($field_name, $class)
{
    $url = pixoo_home_acf_image_url($field_name);

    if ($url === '') {
        return '';
    }

    return '<img class="' . esc_attr($class) . '" src="' . esc_url($url) . '" alt="" loading="lazy">';
}

function pixoo_home_replace_once($pattern, $replacement, $html)
{
    return preg_replace($pattern, $replacement, $html, 1) ?? $html;
}

function pixoo_home_replace_reference_image($html, $target_index, $image)
{
    $current_index = 0;

    $html = preg_replace_callback(
        '/<span class="refs__media">.*?<\/span>/s',
        static function ($matches) use (&$current_index, $target_index, $image) {
            $current_index++;

            if ($current_index !== $target_index) {
                return $matches[0];
            }

            $alt = $image['alt'] !== '' ? $image['alt'] : $image['title'];

            return '<span class="refs__media"><img class="refs__img" src="' . esc_url($image['url']) . '" alt="' . esc_attr($alt) . '" loading="lazy"></span>';
        },
        $html
    ) ?? $html;

    if ($image['title'] === '') {
        return $html;
    }

    $current_index = 0;

    return preg_replace_callback(
        '/<span\s+class="refs__card-title">.*?<\/span>/s',
        static function ($matches) use (&$current_index, $target_index, $image) {
            $current_index++;

            if ($current_index !== $target_index) {
                return $matches[0];
            }

            return '<span class="refs__card-title">' . esc_html($image['title']) . '</span>';
        },
        $html
    ) ?? $html;
}

function pixoo_home_replace_benefit_image($html, $target_index, $image)
{
    $current_index = 0;

    return preg_replace_callback(
        '/<div class="benefits__media">.*?<\/div>/s',
        static function ($matches) use (&$current_index, $target_index, $image) {
            $current_index++;

            if ($current_index !== $target_index) {
                return $matches[0];
            }

            $alt = $image['alt'] !== '' ? $image['alt'] : $image['title'];

            return '<div class="benefits__media"><img src="' . esc_url($image['url']) . '" alt="' . esc_attr($alt) . '" loading="lazy"></div>';
        },
        $html
    ) ?? $html;
}

function pixoo_home_filter_section_html($section, $html)
{
    if ($section === 'process') {
        for ($index = 1; $index <= 4; $index++) {
            $image = pixoo_home_acf_image('process_image_' . $index, 'pixoo-acf-image pixoo-acf-image--process');

            if ($image === '') {
                continue;
            }

            $html = pixoo_home_replace_once(
                '/<div class="process__image-placeholder"><\/div>/',
                '<div class="process__image-placeholder">' . $image . '</div>',
                $html
            );
        }
    }

    if ($section === 'benefits') {
        for ($index = 1; $index <= 4; $index++) {
            $image = pixoo_home_acf_image_data('benefit_image_' . $index);

            if ($image['url'] === '') {
                continue;
            }

            $html = pixoo_home_replace_benefit_image($html, $index, $image);
        }
    }

    if ($section === 'additional-services') {
        for ($index = 1; $index <= 3; $index++) {
            $image = pixoo_home_acf_image('service_image_' . $index, 'pixoo-acf-image pixoo-acf-image--service');

            if ($image === '') {
                continue;
            }

            $html = pixoo_home_replace_once(
                '/<div class="additional-services__media" aria-hidden="true"><\/div>/',
                '<div class="additional-services__media" aria-hidden="true">' . $image . '</div>',
                $html
            );
        }
    }

    if ($section === 'references-preview') {
        for ($index = 1; $index <= 4; $index++) {
            $image = pixoo_home_acf_image_data('reference_image_' . $index);

            if ($image['url'] === '') {
                continue;
            }

            $html = pixoo_home_replace_reference_image($html, $index, $image);
        }
    }

    if ($section === 'about') {
        $image = pixoo_home_acf_image_data('about_image');

        if ($image['url'] !== '') {
            $alt = $image['alt'] !== '' ? $image['alt'] : $image['title'];
            $html = preg_replace(
                '/<div class="about__portrait-inner">.*?<\/div>/s',
                '<div class="about__portrait-inner"><img src="' . esc_url($image['url']) . '" alt="' . esc_attr($alt) . '" class="about__portrait-image" loading="lazy"></div>',
                $html,
                1
            ) ?? $html;
        }
    }

    return $html;
}
