<?php

if (!defined('ABSPATH')) {
    exit;
}

function pixoo_blog_index_url()
{
    return home_url('/blog/');
}

function pixoo_blog_reading_time($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();
    $content = wp_strip_all_tags((string) get_post_field('post_content', $post_id));
    $word_count = str_word_count($content);
    $minutes = max(1, (int) ceil($word_count / 200));

    return sprintf(_n('%d perc olvasás', '%d perc olvasás', $minutes, 'pixoo'), $minutes);
}

function pixoo_blog_category_label($post_id = 0)
{
    $categories = get_the_category($post_id ?: get_the_ID());

    if (!$categories) {
        return __('Blog', 'pixoo');
    }

    return $categories[0]->name;
}

function pixoo_blog_category_slugs($post_id = 0)
{
    $categories = get_the_category($post_id ?: get_the_ID());

    if (!$categories) {
        return 'blog';
    }

    return implode(' ', array_map(static function ($category) {
        return sanitize_html_class($category->slug);
    }, $categories));
}

function pixoo_blog_image_url($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();

    if (has_post_thumbnail($post_id)) {
        return get_the_post_thumbnail_url($post_id, 'large') ?: pixoo_asset('images/blog/wordpress.svg');
    }

    $categories = get_the_category($post_id);
    $slug = $categories ? $categories[0]->slug : 'wordpress';
    $fallbacks = [
        'ai' => 'images/blog/tartalom.svg',
        'design' => 'images/blog/mobile-ux.svg',
        'seo' => 'images/blog/seo.svg',
        'uzlet' => 'images/blog/webshop.svg',
        'weboldal' => 'images/blog/landing.svg',
        'wordpress' => 'images/blog/wordpress.svg',
    ];

    return pixoo_asset($fallbacks[$slug] ?? 'images/blog/wordpress.svg');
}

function pixoo_blog_excerpt($post_id = 0)
{
    $post_id = $post_id ?: get_the_ID();

    if (has_excerpt($post_id)) {
        return get_the_excerpt($post_id);
    }

    return wp_trim_words(wp_strip_all_tags((string) get_post_field('post_content', $post_id)), 28);
}

function pixoo_blog_card($post)
{
    $post_id = $post->ID;
    ?>
    <article class="blog-card" data-blog-card data-blog-category="<?php echo esc_attr(pixoo_blog_category_slugs($post_id)); ?>">
      <a class="blog-card__media" href="<?php echo esc_url(get_permalink($post_id)); ?>" aria-label="<?php echo esc_attr__('Cikk megnyitása', 'pixoo'); ?>">
        <img
          src="<?php echo esc_url(pixoo_blog_image_url($post_id)); ?>"
          alt="<?php echo esc_attr(get_the_title($post_id)); ?>"
          loading="lazy"
        >
        <span><?php echo esc_html(pixoo_blog_category_label($post_id)); ?></span>
      </a>
      <div class="blog-card__content">
        <div class="blog-card__meta">
          <span class="blog-card__topic"><?php echo esc_html(pixoo_blog_category_label($post_id)); ?></span>
          <time datetime="<?php echo esc_attr(get_the_date('Y-m-d', $post_id)); ?>"><?php echo esc_html(get_the_date('Y. F j.', $post_id)); ?></time>
          <span class="blog-card__readtime"><?php echo esc_html(pixoo_blog_reading_time($post_id)); ?></span>
        </div>
        <h3 class="blog-card__title">
          <a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html(get_the_title($post_id)); ?></a>
        </h3>
        <p class="blog-card__excerpt"><?php echo esc_html(pixoo_blog_excerpt($post_id)); ?></p>
        <a class="blog-card__link" href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php esc_html_e('Elolvasom', 'pixoo'); ?></a>
      </div>
    </article>
    <?php
}
