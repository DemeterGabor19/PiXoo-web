<?php
/**
 * Template Name: Árak
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main>
  <?php pixoo_static_section('pricing-configurator'); ?>
</main>

<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

<?php
get_footer();
