<?php
require get_template_directory() . '/template-pricing.php';
