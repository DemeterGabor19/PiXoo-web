<?php
require get_template_directory() . '/page-feltetelek.php';
