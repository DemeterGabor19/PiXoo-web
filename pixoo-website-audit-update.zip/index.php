<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="legal-page">
  <section class="legal-hero">
    <div class="legal-hero__container">
      <p class="legal-hero__eyebrow"><?php esc_html_e('PiXoo', 'pixoo'); ?></p>
      <h1><?php bloginfo('name'); ?></h1>
      <p><?php bloginfo('description'); ?></p>
    </div>
  </section>
</main>

<?php
get_footer();
