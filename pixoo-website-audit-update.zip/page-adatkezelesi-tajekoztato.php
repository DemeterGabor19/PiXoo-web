<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="legal-page">
  <section class="legal-hero">
    <div class="legal-hero__container">
      <p class="legal-hero__eyebrow"><?php esc_html_e('Adatvédelem', 'pixoo'); ?></p>
      <h1><?php esc_html_e('Adatkezelési tájékoztató', 'pixoo'); ?></h1>
      <p><?php esc_html_e('Ez a tájékoztató a pixoo.hu weboldalon keresztül történő kapcsolatfelvételre, ajánlatkérésre, sütikre és mérési megoldásokra vonatkozik.', 'pixoo'); ?></p>
      <span><?php esc_html_e('Hatályos: 2026. június 17.', 'pixoo'); ?></span>
    </div>
  </section>

  <section class="legal-content">
    <div class="legal-content__container">
      <article class="legal-card">
        <h2><?php esc_html_e('1. Az adatkezelő adatai', 'pixoo'); ?></h2>
        <dl>
          <div><dt><?php esc_html_e('Név', 'pixoo'); ?></dt><dd><?php esc_html_e('Demeter Gábor egyéni vállalkozó', 'pixoo'); ?></dd></div>
          <div><dt><?php esc_html_e('Székhely', 'pixoo'); ?></dt><dd><?php esc_html_e('6400 Kiskunhalas, Halászcsárda u. 4.', 'pixoo'); ?></dd></div>
          <div><dt><?php esc_html_e('Adószám', 'pixoo'); ?></dt><dd><?php esc_html_e('67305292-1-23', 'pixoo'); ?></dd></div>
          <div><dt><?php esc_html_e('E-mail', 'pixoo'); ?></dt><dd><a href="mailto:hello@pixoo.hu">hello@pixoo.hu</a></dd></div>
          <div><dt><?php esc_html_e('Telefon', 'pixoo'); ?></dt><dd><a href="tel:+36306782224">+36 30 678 2224</a></dd></div>
          <div><dt><?php esc_html_e('Weboldal', 'pixoo'); ?></dt><dd>pixoo.hu</dd></div>
        </dl>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('2. Kapcsolatfelvétel és ajánlatkérés', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A kapcsolatfelvételi és ajánlatkérő űrlapok célja, hogy az érdeklődő projektigényt küldhessen, és erre választ, pontosítást vagy egyedi ajánlatot kaphasson.', 'pixoo'); ?></p>
        <ul>
          <li><?php esc_html_e('Kezelt adatok: név, e-mail cím, telefonszám, cég vagy projekt neve, projekt típusa, üzenet tartalma, kiválasztott szolgáltatások.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Adatkezelés célja: kapcsolatfelvétel, ajánlatkészítés, megkeresések megválaszolása.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Jogalap: az érintett hozzájárulása, valamint ajánlatkérés esetén szerződéskötést megelőző lépések megtétele.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Megőrzési idő: eredménytelen vagy szerződéshez nem vezető megkeresés esetén legfeljebb 6 hónap.', 'pixoo'); ?></li>
        </ul>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('3. Hírlevél', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A weboldalon később hírlevél-feliratkozási lehetőség is működhet. Hírlevelet csak külön, önkéntes feliratkozás alapján küldök.', 'pixoo'); ?></p>
        <ul>
          <li><?php esc_html_e('Kezelt adatok: név, e-mail cím, feliratkozás időpontja, technikai naplóadatok.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Adatkezelés célja: szakmai tartalmak, ajánlatok és hírek küldése.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Jogalap: hozzájárulás.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Megőrzési idő: leiratkozásig vagy a hozzájárulás visszavonásáig.', 'pixoo'); ?></li>
        </ul>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('4. Sütik, analitika és marketing mérés', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A weboldal technikai sütiket használhat a működéshez, továbbá hozzájárulás alapján analitikai és marketing célú mérések is működhetnek, például Google Analytics, Google Ads konverziómérés és Meta/Facebook Pixel.', 'pixoo'); ?></p>
        <ul>
          <li><?php esc_html_e('Technikai sütik: a weboldal biztonságos és megfelelő működéséhez szükségesek.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Analitikai sütik: látogatottság és felhasználói viselkedés elemzésére szolgálnak.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Marketing sütik: hirdetések mérésére, célzására és hatékonyságának javítására szolgálhatnak.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Jogalap: technikai sütiknél jogos érdek vagy szükségesség, analitikai és marketing sütiknél hozzájárulás.', 'pixoo'); ?></li>
        </ul>
        <p><?php esc_html_e('Analitikai és marketing sütik csak megfelelő hozzájáruláskezelő megoldás beállítása után aktiválhatók.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('5. Spamvédelem', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Az űrlapok védelme érdekében a weboldal Cloudflare Turnstile spamvédelmet és rejtett technikai mezőt használhat. Ezek célja a visszaélések, automatizált beküldések és kéretlen üzenetek kiszűrése.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('6. Adatfeldolgozók', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A weboldal működéséhez és az üzenetek kezeléséhez adatfeldolgozók vehetők igénybe.', 'pixoo'); ?></p>
        <ul>
          <li><?php esc_html_e('Tárhelyszolgáltató: Sybell.', 'pixoo'); ?></li>
          <li><?php esc_html_e('E-mail szolgáltató: az üzleti levelezés technikai szolgáltatója.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Analitikai és marketing szolgáltatók: Google, Meta/Facebook, amennyiben ezek a mérések élesítve vannak.', 'pixoo'); ?></li>
          <li><?php esc_html_e('Spamvédelmi szolgáltató: Cloudflare, amennyiben Turnstile védelem működik.', 'pixoo'); ?></li>
        </ul>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('7. Érintetti jogok', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Az érintett jogosult tájékoztatást kérni az adatkezelésről, hozzáférést kérni a személyes adataihoz, kérni azok helyesbítését, törlését vagy kezelésének korlátozását, tiltakozni bizonyos adatkezelések ellen, valamint visszavonni a hozzájárulását.', 'pixoo'); ?></p>
        <p><?php esc_html_e('Kérését a', 'pixoo'); ?> <a href="mailto:hello@pixoo.hu">hello@pixoo.hu</a> <?php esc_html_e('e-mail címen tudja jelezni.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('8. Jogorvoslat', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Adatvédelmi panasz esetén először érdemes közvetlenül az adatkezelőhöz fordulni. Emellett panasz tehető a Nemzeti Adatvédelmi és Információszabadság Hatóságnál.', 'pixoo'); ?></p>
        <ul>
          <li><?php esc_html_e('Nemzeti Adatvédelmi és Információszabadság Hatóság', 'pixoo'); ?></li>
          <li><?php esc_html_e('Honlap:', 'pixoo'); ?> <a href="https://www.naih.hu/" target="_blank" rel="noopener">www.naih.hu</a></li>
          <li><?php esc_html_e('Postacím: 1363 Budapest, Pf. 9.', 'pixoo'); ?></li>
        </ul>
      </article>
    </div>
  </section>
</main>

<?php
get_footer();
