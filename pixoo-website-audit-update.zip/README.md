# PiXoo WordPress Theme

Elso atmeneti fazis: a theme statikusan rendereli a jelenlegi HTML szekciokat.

Kovetkezo lepes: szekcionkent ACF mezokre bontani:

- hero
- features
- process
- additional services
- references
- benefits
- tech stack
- about

