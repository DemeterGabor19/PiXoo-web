<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main>
  <?php
  pixoo_static_section('hero');
  pixoo_static_section('features');
  pixoo_static_section('process');
  pixoo_static_section('additional-services');
  pixoo_static_section('references-preview');
  pixoo_static_section('benefits');
  pixoo_static_section('tech-stack');
  pixoo_static_section('about');
  ?>
</main>

<?php
get_footer();
