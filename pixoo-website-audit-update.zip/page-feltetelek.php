<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="legal-page">
  <section class="legal-hero">
    <div class="legal-hero__container">
      <p class="legal-hero__eyebrow"><?php esc_html_e('Feltételek', 'pixoo'); ?></p>
      <h1><?php esc_html_e('Használati és szolgáltatási feltételek', 'pixoo'); ?></h1>
      <p>
        <?php esc_html_e('Ezek a feltételek a pixoo.hu weboldal használatára, az ajánlatkérésre és az egyedi webes fejlesztési szolgáltatások előkészítésére vonatkoznak.', 'pixoo'); ?>
      </p>
      <span><?php esc_html_e('Hatályos: 2026. június 17.', 'pixoo'); ?></span>
    </div>
  </section>

  <section class="legal-content">
    <div class="legal-content__container">
      <article class="legal-card">
        <h2><?php esc_html_e('1. Szolgáltató adatai', 'pixoo'); ?></h2>
        <dl>
          <div>
            <dt><?php esc_html_e('Név', 'pixoo'); ?></dt>
            <dd><?php esc_html_e('Demeter Gábor egyéni vállalkozó', 'pixoo'); ?></dd>
          </div>
          <div>
            <dt><?php esc_html_e('Székhely', 'pixoo'); ?></dt>
            <dd><?php esc_html_e('6400 Kiskunhalas, Halászcsárda u. 4.', 'pixoo'); ?></dd>
          </div>
          <div>
            <dt><?php esc_html_e('Adószám', 'pixoo'); ?></dt>
            <dd><?php esc_html_e('67305292-1-23', 'pixoo'); ?></dd>
          </div>
          <div>
            <dt><?php esc_html_e('E-mail', 'pixoo'); ?></dt>
            <dd><a href="mailto:hello@pixoo.hu">hello@pixoo.hu</a></dd>
          </div>
          <div>
            <dt><?php esc_html_e('Telefon', 'pixoo'); ?></dt>
            <dd><a href="tel:+36306782224">+36 30 678 2224</a></dd>
          </div>
        </dl>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('2. A weboldal célja', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A pixoo.hu bemutatkozó weboldal, amely weboldal, webshop, WordPress-fejlesztés, design, SEO-alapok és karbantartási jellegű szolgáltatások iránti érdeklődést és ajánlatkérést fogad.', 'pixoo'); ?></p>
        <p><?php esc_html_e('A weboldalon nem történik online rendelés, automatikus szerződéskötés vagy online fizetés. Az űrlapok elküldése ajánlatkérésnek vagy kapcsolatfelvételnek minősül.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('3. Ajánlatkérés és egyedi ajánlat', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Az árkalkulátor és a weboldalon megjelenő árak tájékoztató jellegű induló árak. A pontos díjazás mindig az adott projekt részletei, funkciói, tartalmi igényei, határideje és technikai feltételei alapján, egyedi ajánlatban kerül meghatározásra.', 'pixoo'); ?></p>
        <p><?php esc_html_e('Az ajánlat elfogadása külön írásbeli visszaigazolással, e-mailben vagy szerződésben történhet. Az ajánlatban szereplő határidők és díjak csak az abban rögzített feltételek mellett érvényesek.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('4. Teljesítés és együttműködés', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A projekt sikeres teljesítéséhez szükség lehet az ügyfél együttműködésére, például tartalmak, képek, hozzáférések, arculati anyagok, visszajelzések vagy jóváhagyások átadására.', 'pixoo'); ?></p>
        <p><?php esc_html_e('A határidők módosulhatnak, ha a szükséges információk vagy jóváhagyások késve érkeznek meg, vagy a projekt terjedelme a munka során változik.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('5. Díjfizetés', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Eltérő megállapodás hiányában a díjfizetés a projekt végén, átadáskor vagy a felek által elfogadott teljesítési pont után történik, amikor a munka mindkét fél számára elfogadható állapotba került.', 'pixoo'); ?></p>
        <p><?php esc_html_e('Nagyobb vagy több ütemből álló projektnél külön megállapodás alapján előleg, részszámlázás vagy mérföldköves teljesítés is rögzíthető.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('6. Karbantartás és utólagos módosítások', 'pixoo'); ?></h2>
        <p><?php esc_html_e('Karbantartási szolgáltatás eseti alapon vagy külön megállapodás szerint kérhető. A karbantartás, hibajavítás, frissítés vagy utólagos bővítés feltételeit és díját külön egyeztetés vagy ajánlat tartalmazza.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('7. Szellemi tulajdon', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A projekt során készített egyedi design, frontend kód, sablon, tartalmi struktúra és egyéb kreatív anyag felhasználási joga a díj rendezését követően, az ajánlatban vagy megállapodásban rögzített körben száll át az ügyfélre.', 'pixoo'); ?></p>
        <p><?php esc_html_e('Harmadik féltől származó eszközök, betűtípusok, képek, bővítmények vagy szolgáltatások saját licencfeltételeik szerint használhatók.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('8. Felelősség', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A szolgáltató törekszik a gondos, szakmailag megfelelő teljesítésre. Nem vállalható felelősség olyan hibáért vagy kiesésért, amely harmadik fél szolgáltatásából, tárhelyből, domainből, külső bővítményből, fizetési szolgáltatóból, hozzáférési hibából vagy az ügyfél által végzett módosításból ered.', 'pixoo'); ?></p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('9. Adatkezelés', 'pixoo'); ?></h2>
        <p>
          <?php esc_html_e('A weboldal használatával és az űrlapok elküldésével kapcsolatos adatkezelésekről az', 'pixoo'); ?>
          <a href="https://staging.pixoo.hu/adatkezelesi-tajekoztato/"><?php esc_html_e('adatkezelési tájékoztató', 'pixoo'); ?></a>
          <?php esc_html_e('ad részletes információt.', 'pixoo'); ?>
        </p>
      </article>

      <article class="legal-card">
        <h2><?php esc_html_e('10. Kapcsolat', 'pixoo'); ?></h2>
        <p><?php esc_html_e('A feltételekkel, ajánlatkéréssel vagy folyamatban lévő projekttel kapcsolatos kérdés esetén az alábbi elérhetőségen lehet kapcsolatba lépni:', 'pixoo'); ?> <a href="mailto:hello@pixoo.hu">hello@pixoo.hu</a>.</p>
      </article>
    </div>
  </section>
</main>

<?php
get_footer();
