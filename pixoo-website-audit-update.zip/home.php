<?php

require get_template_directory() . '/template-blog.php';
